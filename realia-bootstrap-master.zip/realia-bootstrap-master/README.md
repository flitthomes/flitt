# Realia Bootstrap Starter Theme

Starter theme in Bootstrap for Realia real estate WordPress plugin.

## Compile SASS files

```
$ npm install gulp gulp-sass
$ gulp watch
```