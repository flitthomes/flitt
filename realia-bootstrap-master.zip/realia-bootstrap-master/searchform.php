<form class="search-form" action="<?php bloginfo('url'); ?>" method="get" role="search">
	<div class="input-group">
		<input type="text" class="form-control" name="s" placeholder="Search …">
		<div class="input-group-btn">
			<button class="btn btn-default" type="submit">
				<span class="glyphicon glyphicon-search"></span>
			</button>
		</div>
	</div>
</form>