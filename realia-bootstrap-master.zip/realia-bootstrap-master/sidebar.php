<?php if ( is_active_sidebar( 'sidebar-1' ) ) : ?>
	<div class="sidebar col-sm-4 col-md-3">
		<?php dynamic_sidebar( 'sidebar-1' ); ?>
	</div><!-- /.sidebar -->
<?php endif; ?>