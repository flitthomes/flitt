<?php if ( is_active_sidebar( 'sidebar-top' ) ) : ?>
	<div class="sidebar-top">
		<?php dynamic_sidebar( 'sidebar-top' ); ?>
	</div><!-- /.sidebar -->
<?php endif; ?>